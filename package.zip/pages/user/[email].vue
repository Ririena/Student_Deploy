<template>
  <CardPostProfile />
</template>



<style></style>
