<div class="flex-1">
    <!-- Header -->
    <div class="bg-white shadow px-2 py-4 navbar bg-base-100">
        <button>
            <i @click="toggleSidebar" class="ri-menu-2-line focus text-2xl  xs:hidden sm:hidden md:hidden lg:inline xl:inline"></i>
          </button>
          <a class="btn btn-ghost text-xl">STUDENT FILE</a>
    </div>
    <!-- CONTENT-->
    <div class="p-8 text-purple-400 font-extrabold">KONTEN
      
    </div>