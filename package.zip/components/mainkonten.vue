<template>

<div class="p-8 text-purple-400 font-extrabold">KONTENs
        
    </div>
    </template>
<script>
import { ref } from 'vue';

export default {
  props: ['toggleSidebar'],
};
</script>

<style scoped>
/* Add your main content styles here */
</style>