<template>
  <div class="btm-nav bg-fuchsia-300 md:hidden lg:hidden xl:hidden ">
    <button>
      <i class="ri-home-3-fill"></i>
    </button>
    <button class="">
      <i class="ri-search-line"></i>
    </button>
    <button>
      <i class="ri-chat-upload-line"></i>
    </button>
    <button>
      <i class="ri-movie-line"></i>
    </button>
    <button>
  <div class="avatar">
      <div class="w-12 rounded-full ring ring-fuchsia-600 ring-offset-green-100 ring-offset-2">
          <img src="https://images.unsplash.com/photo-1580477667995-2b94f01c9516?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt=""/>
      </div>
  </div>
    </button>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>