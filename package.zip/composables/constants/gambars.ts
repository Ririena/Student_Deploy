export const gambars = [
  {
    id: 0,
    name: "post1",
    description: "No",
    profile: "Woody",
    isUpload: true,
    image: "https://images.unsplash.com/photo-1580477667995-2b94f01c9516?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
  },
  {
    id: 1,
    name: "post2",
    description: "Yes",
    profile: "Reimu",
    isUpload: true,
    image: "https://i.pinimg.com/736x/23/b2/14/23b214831b6b9d7e07dd77696fbbaa64.jpg",
  },
];
